
export const DEFAULT_SHEET_ID = '1JPdXwoH2TfEhFVkidOkO_x3mrmJobdIKZSAL7qul_wM';
export const ALLOWED_DOMAIN = '@fedshi.com';
export const LOCAL_STORAGE_KEY = 'fedshi_youtube_mod_v1';
export const SESSION_KEY = 'fedshi_session';
// User provided YouTube API Key
export const YOUTUBE_API_KEY = 'AIzaSyCog7EOtqNfR1HNgiIdfSGWAraqBZ0bJvk';
// User provided YouTube Channel ID
export const YOUTUBE_CHANNEL_ID = 'UCRy5L9IoV4CvNu8AgB89qYg';
